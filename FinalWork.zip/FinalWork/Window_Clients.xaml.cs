﻿using Client_db;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalWork
{
    /// <summary>
    /// Interaction logic for Window_Clients.xaml
    /// </summary>
    public partial class Window_Clients : Window
    {
        private string clientName;

        public Window_Clients(string name)
        {
            InitializeComponent();

            clientName = name;
            NameTextBox.Text = name;
        }

        private void Button_Okay(object sender, RoutedEventArgs e)
        {
            MainPanel.Visibility = Visibility.Visible;
            ButtonContact.Visibility = Visibility.Visible;
            ButtonGroup.Visibility = Visibility.Visible;
        }
        private void Button_Check_User(object sender, RoutedEventArgs e)
        {
            Checking_users.Items.Clear();
            MessageBox.Show("Open connection to server first.");
        }

        private void Button_Contact(object sender, RoutedEventArgs e)
        {
            if (Checking_users.SelectedItem == null)
            {
                MessageBox.Show("Choose user");
                return;
            }

            string contactName = Checking_users.SelectedItem.ToString();

            if (contactName == clientName)
            {
                MessageBox.Show("You cannot add yourself!");
                return;
            }

            using (Clients_db db = new Clients_db())
            {
                var user = db.Clients.FirstOrDefault(x => x.Name == clientName);

                var contact = db.Clients.FirstOrDefault(x => x.Name == contactName);

                if (user == null || contact == null)
                {
                    MessageBox.Show("User not found!");
                    return;
                }

                bool exists = db.Contacts.Any(x => x.ClientId == user.Id && x.ContactClientId == contact.Id);

                if (exists)
                {
                    MessageBox.Show("Contact already exists!");
                    return;
                }

                Contact newContact = new Contact()
                {
                    ClientId = user.Id,
                    ContactClientId = contact.Id
                };

                db.Contacts.Add(newContact);
                db.SaveChanges();
            }

            MessageBox.Show("Contact added");
        }

        private void ShowContacts()
        {
            Checking_users.Items.Clear();

            using (Clients_db db = new Clients_db())
            {
                var user = db.Clients.FirstOrDefault(x => x.Name == clientName);

                if (user == null)
                    return;

                var contacts = db.Contacts
                    .Where(x => x.ClientId == user.Id)
                    .Select(x => x.ContactClientId)
                    .ToList();

                var names = db.Clients
                    .Where(x => contacts.Contains(x.Id))
                    .Select(x => x.Name)
                    .ToList();

                foreach (string name in names)
                {
                    Checking_users.Items.Add(name);
                }
            }
        }
        private void Button_Group_Chat(object sender, RoutedEventArgs e)
        {
            var selectedUsers = Checking_users.SelectedItems
                .Cast<string>()
                .ToList();

            if (selectedUsers.Count < 2)
            {
                MessageBox.Show("Choose at least 2 users!");
                return;
            }

            Windows_Clients_Chat chat = new Windows_Clients_Chat(clientName, "", selectedUsers);

            chat.Show();
        }
        private void Button_Go_Chat(object sender, RoutedEventArgs e)
        {
            if (Checking_users.SelectedItem == null)
            {
                MessageBox.Show("Choose user!");
                return;
            }

            string receiver = Checking_users.SelectedItem.ToString();

            Windows_Clients_Chat chat = new Windows_Clients_Chat(clientName, receiver);

            chat.Show();
        }
    }
}
