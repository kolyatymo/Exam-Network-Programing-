﻿using Client_Request;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FinalWork
{
    /// <summary>
    /// Interaction logic for Windows_Clients_Chat.xaml
    /// </summary>
    public partial class Windows_Clients_Chat : Window
    {
        private string remoteIP = "127.0.0.1";
        private int port = 4040;

        private TcpClient client = new TcpClient();

        private string clientName = "";
        private string receiver = "";

        private string groupId = "";

        private List<string> groupUsers = new List<string>();

        private bool isGroup = false;

        public Windows_Clients_Chat(string name, string user)
        {
            InitializeComponent();

            clientName = name;
            receiver = user;

            Title = "Chat with " + receiver;
        }

        public Windows_Clients_Chat(
            string name, string user, List<string> users)
        {
            InitializeComponent();

            clientName = name;

            groupUsers = users;
            groupId = Guid.NewGuid().ToString();

            isGroup = true;

            Title = "Group Chat";
        }

        private async void Click_Connect(
            object sender, RoutedEventArgs e)
        {
            try
            {
                if (client.Connected)
                    return;

                client = new TcpClient();

                await client.ConnectAsync(
                    IPAddress.Parse(remoteIP), port);

                await SendRequest(new ClientCommand(
                    "", clientName, DateTime.Now,
                    RequestCommand.Join));

                MessageBox.Show("Connected!");

                if (isGroup)
                {
                    ClientCommand groupCommand = new ClientCommand();

                    groupCommand.Command = RequestCommand.CreateGroup;
                    groupCommand.Name = clientName;
                    groupCommand.GroupId = groupId;
                    groupCommand.Users = groupUsers;

                    await SendRequest(groupCommand);
                }

                else
                {
                    ClientCommand request = new ClientCommand(
                        RequestCommand.OnlineUsersRequest);

                    await SendRequest(request);
                }

                ServerListener();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private async Task SendRequest(ClientCommand command)
        {
            if (!client.Connected)
                return;

            NetworkStream ns = client.GetStream();

            StreamWriter sw = new StreamWriter(
                ns, System.Text.Encoding.UTF8, 1024, true);

            string json = JsonSerializer.Serialize(command);

            await sw.WriteLineAsync(json);

            await sw.FlushAsync();
        }
        private async Task ServerListener()
        {
            try
            {
                NetworkStream ns = client.GetStream();

                StreamReader sr = new StreamReader(
                    ns, System.Text.Encoding.UTF8, false, 1024, true);

                while (client.Connected)
                {
                    string? response = await sr.ReadLineAsync();

                    if (response == null)
                        break;

                    ClientCommand? command =
                        JsonSerializer.Deserialize<ClientCommand>(response);

                    if (command == null)
                        continue;

                    Dispatcher.Invoke(() =>
                    {
                        switch (command.Command)
                        {
                            case RequestCommand.Message:
                            case RequestCommand.PrivateMessage:
                            case RequestCommand.GroupMessage:

                                ListBoxMessage.Items.Add(
                                    command.Name + " [" +
                                    command.Time + "]: " +
                                    command.Message);

                                break;

                            case RequestCommand.OnlineUsers:

                                ListBoxMessage.Items.Add(
                                    "Online users: " +
                                    string.Join(", ", command.Users));

                                break;
                        }
                    });
                }
            }
            catch
            {
                Dispatcher.Invoke(() =>
                {
                    MessageBox.Show("Connection lost");
                });
            }
        }

        private async void Click_Send(
            object sender, RoutedEventArgs e)
        {
            if (!client.Connected)
            {
                MessageBox.Show("Connect first");
                return;
            }

            if (msgTextBox.Text == "")
                return;

            ClientCommand command = new ClientCommand();

            command.Message = msgTextBox.Text;
            command.Name = clientName;
            command.Time = DateTime.Now;

            if (isGroup)
            {
                command.Command = RequestCommand.GroupMessage;
                command.GroupId = groupId;
            }
            else
            {
                command.Command = RequestCommand.PrivateMessage;
                command.Receiver = receiver;
            }

            await SendRequest(command);

            ListBoxMessage.Items.Add(clientName + "  DateTime.Now --> " + msgTextBox.Text);

            msgTextBox.Clear();
        }

        private async void Click_Disconnect(
            object sender, RoutedEventArgs e)
        {
            if (client.Connected)
            {
                await SendRequest(
                    new ClientCommand(RequestCommand.Leave));

                client.Close();

                MessageBox.Show("Disconnected!");

                this.Close();
            }
        }

        private void CLick_Send_Folder(
            object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            if (dialog.ShowDialog() == true)
            {
                ListBoxMessage.Items.Add("Selected file --> " + dialog.FileName);
            }
        }
        private void Click_Send_Image(
            object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            if (dialog.ShowDialog() == true)
            {
                ListBoxMessage.Items.Add("Selected image --> " + dialog.FileName);
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            if (client.Connected)
                client.Close();

            base.OnClosed(e);
        }
    }
}
