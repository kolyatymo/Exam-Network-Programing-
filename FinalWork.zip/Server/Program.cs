﻿using System.Net.Sockets;
using System.Net;
using System.Text.Json;
using Client_Request;

internal class Program
{
    private const string localIp = "127.0.0.1";
    private const int port = 4040;

    static TcpListener server;

    private static void Main(string[] args)
    {
        IPEndPoint localEndPoint =
            new IPEndPoint(IPAddress.Parse(localIp), port);

        server = new TcpListener(localEndPoint);

        Chat chat = new Chat();

        server.Start();

        Console.WriteLine("Server started!");

        while (true)
        {
            Console.WriteLine("Waiting for a request...");

            TcpClient client = server.AcceptTcpClient();

            Console.WriteLine("Got a TcpClient");

            Task.Run(() => chat.AddMember(client));
        }
    }
}

class Chat
{
    private const int MaxPeople = 10;

    private List<TcpClient> members = new List<TcpClient>();

    private List<string> names = new List<string>();

    private Dictionary<string, List<string>> groups =
        new Dictionary<string, List<string>>();

    private readonly object locker = new object();

    public void AddMember(TcpClient client)
    {
        try
        {
            ClientCommand request = GetClientCommand(client);

            if (request.Command == RequestCommand.Join)
            {
                lock (locker)
                {
                    if (members.Count >= MaxPeople ||
                        names.Contains(request.Name))
                    {
                        client.Close();
                        return;
                    }

                    members.Add(client);
                    names.Add(request.Name);
                }

                Console.WriteLine(request.Name + " was added");

                Task.Run(() => ListenerClient(client));
            }
        }
        catch
        {
            client.Close();
        }
    }

    public void RemoveMember(TcpClient client)
    {
        lock (locker)
        {
            int index = members.IndexOf(client);

            if (index != -1)
            {
                Console.WriteLine(names[index] + " Leave");

                members.RemoveAt(index);
                names.RemoveAt(index);
            }
        }

        client.Close();
        SendOnlineUsers();
    }

    public void ListenerClient(TcpClient client)
    {
        bool isExit = false;

        while (!isExit)
        {
            try
            {
                ClientCommand command = GetClientCommand(client);

                switch (command.Command)
                {
                    case RequestCommand.Leave:
                        RemoveMember(client);
                        isExit = true;
                        break;

                    case RequestCommand.OnlineUsersRequest:
                        SendOnlineUsers(client);
                        break;

                    case RequestCommand.PrivateMessage:
                        SendPrivateMessage(command);
                        break;

                    case RequestCommand.CreateGroup:
                        CreateGroup(command);
                        break;

                    case RequestCommand.GroupMessage:
                        SendGroupMessage(command);
                        break;
                }
            }
            catch
            {
                RemoveMember(client);
                isExit = true;
            }
        }
    }

    private void SendOnlineUsers(TcpClient receiver = null)
    {
        List<string> online;

        lock (locker)
        {
            online = new List<string>(names);
        }

        ClientCommand command = new ClientCommand();

        command.Command = RequestCommand.OnlineUsers;
        command.Users = online;

        if (receiver != null)
        {
            SendMessage(command, receiver);
            return;
        }

        lock (locker)
        {
            foreach (var member in members)
            {
                SendMessage(command, member);
            }
        }
    }

    private void SendPrivateMessage(ClientCommand command)
    {
        TcpClient receiver = null;

        lock (locker)
        {
            int index = names.IndexOf(command.Receiver);

            if (index != -1)
                receiver = members[index];
        }

        if (receiver != null)
        {
            SendMessage(command, receiver);
        }
    }

    private void CreateGroup(ClientCommand command)
    {
        lock (locker)
        {
            if (command.Users == null)
                return;

            if (!command.Users.Contains(command.Name))
            {
                command.Users.Add(command.Name);
            }

            groups[command.GroupId] = command.Users
                .Where(x => names.Contains(x))
                .Distinct()
                .ToList();
        }

        Console.WriteLine("Group created --> " + command.GroupId);
    }

    private void SendGroupMessage(ClientCommand command)
    {
        List<string> groupMembers;

        lock (locker)
        {
            if (!groups.ContainsKey(command.GroupId))
                return;

            groupMembers = new List<string>(
                groups[command.GroupId]);
        }

        foreach (string name in groupMembers)
        {
            TcpClient receiver = null;

            lock (locker)
            {
                int index = names.IndexOf(name);

                if (index != -1)
                    receiver = members[index];
            }

            if (receiver != null)
                SendMessage(command, receiver);
        }
    }

    private ClientCommand GetClientCommand(TcpClient client)
    {
        NetworkStream ns = client.GetStream();
        StreamReader sr = new StreamReader(ns);

        string? json = sr.ReadLine();

        if (json == null)
        {
            throw new Exception("Connection close");
        }

        return JsonSerializer.Deserialize<ClientCommand>(json)!;
    }

    private void SendMessage(ClientCommand command, TcpClient receiver)
    {
        try
        {
            NetworkStream ns = receiver.GetStream();
            StreamWriter sw = new StreamWriter(ns);
            sw.WriteLine(JsonSerializer.Serialize(command));

            sw.Flush();
        }
        catch(Exception e) 
        {
            Console.WriteLine(e.Message);
        }
    }
}